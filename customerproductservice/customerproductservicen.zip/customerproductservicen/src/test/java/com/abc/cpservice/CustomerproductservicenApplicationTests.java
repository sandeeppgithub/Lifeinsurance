package com.abc.cpservice;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerproductservicenApplicationTests {

	@Test
	void contextLoads() {
		assertTrue(true);
	}

}
