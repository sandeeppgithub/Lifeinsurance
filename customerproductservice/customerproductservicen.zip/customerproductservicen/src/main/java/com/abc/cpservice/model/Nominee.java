package com.abc.cpservice.model;

public class Nominee {
	
	

}
